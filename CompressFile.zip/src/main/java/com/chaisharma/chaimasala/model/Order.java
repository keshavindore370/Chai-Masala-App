package com.chaisharma.chaimasala.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "orders")
@Data
public class Order {
    @Id
    private String id;
    private String customerName;
    private String productName;

    private String weight;    // e.g., "250g", "500g"
    private int quantity;     // e.g., 1, 2, 5 packets
    private double totalBill; // e.g., 450.00
    // Delivery Details (HTML names se match hona chahiye)
    private String address;
    private String pincode;
    private String phone; // HTML mein name="phone" hai isliye yahan bhi "phone" rakha hai
    private String paymentType = "Cash on Delivery";

    // Status Tracking
    private String status = "PLACED"; // Initial status: PLACED

    // Dates & Info
    private LocalDateTime orderDate = LocalDateTime.now();
    private String estimatedDelivery = "30-45 Minutes"; // Indore special fast delivery!
}