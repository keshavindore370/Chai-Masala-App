package com.chaisharma.chaimasala.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "users") // This must match exactly
@Data
public class User {
    @Id
    private String id;
    private String mobileNumber; // Ensure this name matches what the Repo looks for
    private String password;
}