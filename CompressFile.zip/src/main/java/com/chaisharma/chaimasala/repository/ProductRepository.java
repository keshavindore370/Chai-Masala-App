package com.chaisharma.chaimasala.repository;

import com.chaisharma.chaimasala.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends MongoRepository<Product, String> {
    // Spring Boot automatically creates Save, Delete, and Find methods for you!
}