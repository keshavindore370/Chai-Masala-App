package com.chaisharma.chaimasala.controller;

import com.chaisharma.chaimasala.model.Order;
import com.chaisharma.chaimasala.model.User;
import com.chaisharma.chaimasala.repository.OrderRepository;
import com.chaisharma.chaimasala.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.ArrayList; // 👈 Import added
import java.util.List;      // 👈 Import added

@Controller
public class ProductController {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // 1. Home Page
    @GetMapping("/")
    public String home(Model model, @AuthenticationPrincipal OAuth2User principal, Principal normalUser) {
        if (principal != null) {
            String name = principal.getAttribute("name");
            model.addAttribute("name", name != null ? name : principal.getAttribute("email"));
        } else if (normalUser != null) {
            model.addAttribute("name", normalUser.getName());
        }
        return "index";
    }

    // 2. Checkout/Cart Page
    @GetMapping("/cart")
    public String showCartPage(Model model, Principal principal) {
        if (principal != null) {
            model.addAttribute("name", principal.getName());
        }
        return "cart";
    }

    // 3. Place Order Logic
    @PostMapping("/place-order")
    public String confirmOrder(Principal principal,
                               @AuthenticationPrincipal OAuth2User oauthUser,
                               @ModelAttribute Order order) {

        String customerName = "Guest";
        if (oauthUser != null) {
            customerName = oauthUser.getAttribute("name");
        } else if (principal != null) {
            customerName = principal.getName();
        }
        order.setCustomerName(customerName);
        order.setProductName("Premium Chai Masala Pack");
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PLACED");
        order.setEstimatedDelivery("30-45 Minutes");

        Order savedOrder = orderRepository.save(order);
        return "redirect:/order-success?id=" + savedOrder.getId();
    }

    // 4. Order Success
    @GetMapping("/order-success")
    public String showSuccessPage(@RequestParam(required = false) String id, Model model) {
        model.addAttribute("orderId", id);
        return "order-success";
    }

    // 5. Tracking Page
    @GetMapping("/order-tracking/{id}")
    public String trackOrder(@PathVariable String id, Model model) {
        Order order = orderRepository.findById(id).orElseThrow();
        model.addAttribute("order", order);
        return "order-tracking";
    }

    // 6. Admin Panel (Duplicate fixed & null check added)
    @GetMapping("/admin/orders")
    public String showAdminOrders(Model model) {
        List<Order> orders = orderRepository.findAll();
        model.addAttribute("orders", orders != null ? orders : new ArrayList<>());
        return "admin-orders";
    }

    // 7. Admin Status Update
    @PostMapping("/admin/update-status")
    public String updateStatus(@RequestParam String orderId, @RequestParam String status) {
        Order order = orderRepository.findById(orderId).orElseThrow();
        order.setStatus(status);
        orderRepository.save(order);
        return "redirect:/admin/orders";
    }

    // 8. Cancel Order
    @PostMapping("/order/cancel")
    public String cancelOrder(@RequestParam String orderId) {
        Order order = orderRepository.findById(orderId).orElseThrow();
        order.setStatus("CANCELLED");
        orderRepository.save(order);
        return "redirect:/admin/orders";
    }

    // 9. Auth Routes
    @GetMapping("/login")
    public String showLoginPage(Principal principal) {
        return (principal != null) ? "redirect:/" : "login";
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return "redirect:/login?success";
    }

    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot-password";
    }

    @GetMapping("/adrak-chai")
    public String viewAdrakDetails(Model model, Principal principal) {
        if (principal != null) { model.addAttribute("name", principal.getName()); }
        return "adrak-details";
    }
}